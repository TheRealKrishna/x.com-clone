const express = require('express')
const app = express()
const getUser = require("../middleware/getUser.js")
const { addFollower, removeFollower } = require("../controller/follow.js")


app.post("/addfollower", getUser, addFollower)
app.post("/removefollower", getUser, removeFollower)

module.exports = app